import type React from "react"
export const Chart = () => {
  return null
}

export const ChartContainer = ({ className, ...props }: { className?: string; children: React.ReactNode }) => {
  return <div className={className} {...props} />
}

export const ChartTooltip = () => {
  return null
}

export const ChartTooltipContent = () => {
  return null
}

export const ChartTooltipItem = () => {
  return null
}

export const ChartTooltipLabel = () => {
  return null
}

export const ChartTooltipValue = () => {
  return null
}

export const ChartLegend = () => {
  return null
}

export const ChartLegendItem = () => {
  return null
}
